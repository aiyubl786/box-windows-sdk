﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Box.V2.Plugins.Managers
{
    public interface IBoxMetadataManager : IResourcePlugin
    {

    }
}
